package com.example.s8ulorg;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.s8ulorg.model.NotificationDta;
import com.example.s8ulorg.retrofit.EmployeeApi;
import com.example.s8ulorg.retrofit.RetrofitService;

import java.util.logging.Level;
import java.util.logging.Logger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GenerateNotification extends AppCompatActivity {


    Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generate_notification);

        bt=findViewById(R.id.button21);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                NotificationDta data1 = new NotificationDta();
                data1.setToken_user("akarsh");
                Log.d("jhuiu", data1.getToken_user());


                RetrofitService retrofitService = new RetrofitService();
                EmployeeApi employeeApi = retrofitService.getRetrofit().create(EmployeeApi.class);

                employeeApi.sendnotification1(data1)
                        .enqueue(new Callback<NotificationDta>() {
                            @Override
                            public void onResponse(Call<NotificationDta> call, Response<NotificationDta> response) {

                                Log.d("gyg", response.toString());
                                // Toast.makeText(LiveActivity.this,"Save ff",Toast.LENGTH_LONG).show();
                            }

                            @Override
                            public void onFailure(Call<NotificationDta> call, Throwable t) {

                                // Toast.makeText(LiveActivity.this,"Save failed",Toast.LENGTH_LONG).show();
                                Logger.getLogger(LiveActivity.class.getName()).log(Level.SEVERE, "TDDRDA", t);
                            }
                        });




            }
        });
    }
}