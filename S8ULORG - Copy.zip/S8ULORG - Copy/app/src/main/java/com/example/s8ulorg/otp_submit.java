package com.example.s8ulorg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class otp_submit extends AppCompatActivity
{

    private String mVerificationId;
    String otpreceived;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    FirebaseAuth mAuth;
    Button btn;
    private String number;
    private ProgressBar progressBar;
    private EditText inputCode1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp_submit);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        MaterialToolbar materialToolbar;
        materialToolbar=findViewById(R.id.top_bar);

        materialToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });

        number=getIntent().getStringExtra("mobile");
        btn=findViewById(R.id.submit_otp);
        mAuth=FirebaseAuth.getInstance();
        inputCode1=findViewById(R.id.enter_otp);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (inputCode1.getText().toString().isEmpty()) {
                    Toast.makeText(otp_submit.this, "Please complete the otp", Toast.LENGTH_LONG).show();
                } else {
                    Log.d("TAG", otpreceived);
                    String otpuser = inputCode1.getText().toString();

                    Log.d("TAG", otpuser);

                    PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.getCredential(otpreceived, otpuser);
                    signInWithPhoneAuthCredential(phoneAuthCredential);
                }
            }
        });

        String phone = "+91" + number;
        Log.d("TAG", phone);

        // sendVerificationCode(phone);
        Toast.makeText(otp_submit.this, "Sending Otp", Toast.LENGTH_LONG).show();
        //progressBar.setVisibility(View.VISIBLE);
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(phone)       // Phone number to verify
                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                        .setActivity(otp_submit.this)                 // Activity (for callback binding)
                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                String code=phoneAuthCredential.getSmsCode();
                                //verifyotp(code);
                                signInWithPhoneAuthCredential(phoneAuthCredential);
                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                Log.d("TAG",e.getMessage());

                            }

                            @Override
                            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                super.onCodeSent(s, forceResendingToken);
                                otpreceived = s;
                                // checkotp(otpreceived);
                                Toast.makeText(otp_submit.this, "Otp Sent", Toast.LENGTH_LONG).show();

                                Log.d("TAG", otpreceived);

                            }
                        })          // OnVerificationStateChangedCallbacks
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
        // progressBar.setVisibility(View.GONE);

    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("TAG", "signInWithCredential:success");

                            FirebaseUser user = task.getResult().getUser();
                            String user1 =FirebaseAuth.getInstance().getCurrentUser().getUid();
                            Log.d("TAG",user1);
                            //Intent it=new Intent(VerifyOTPActivity.this,MainActivity.class);
                            //startActivity(it);
                            // finish();

                            checkexistence(user1);
                            // ...
                        } else {
                            // Sign in failed, display a message and update the UI
                            Log.w("TAG", "signInWithCredential:failure", task.getException());
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                            }
                        }
                    }
                });
    }

    private void checkexistence(final String id) {
        Log.d("TAG","In check existence");
        // ValueEventListener getlistner;
        DatabaseReference ref= FirebaseDatabase.getInstance().getReference().child("People");

        ref.child(id)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists())
                        {
                            Log.d("TAG","We are here in if database");
                            Intent it=new Intent(otp_submit.this,dashboard.class);
                         //   it.putExtra("Number",number);
                       //     it.putExtra("ID",id);
                            startActivity(it);


                        }
                        else
                        {
                            Log.d("TAG","We are here in else database");

                      DatabaseReference dref=      FirebaseDatabase.getInstance().getReference().child("People").child(FirebaseAuth.getInstance().getCurrentUser().getUid());

                            HashMap<String,Object> map=new HashMap<>();
                            map.put("Number",number);
                            map.put("Id",id);
                        dref.updateChildren(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                Intent it =new Intent(otp_submit.this,dashboard.class);
                               // it.putExtra("Number",number);
                               // it.putExtra("ID",id);
                                startActivity(it);
                            }
                        });

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        String e =error.getMessage().toString();
                        Log.d("TAG",e);
                        Log.d("TAG","We are here in cancel database");

                    }
                });


    }

}
