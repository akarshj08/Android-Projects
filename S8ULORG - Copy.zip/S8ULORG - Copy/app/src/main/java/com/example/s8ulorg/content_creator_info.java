package com.example.s8ulorg;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.s8ulorg.model.ContentCreatorsData;
import com.example.s8ulorg.model.NotificationDta;
import com.example.s8ulorg.model.Postdata;
import com.example.s8ulorg.retrofit.EmployeeApi;
import com.example.s8ulorg.retrofit.RetrofitService;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class content_creator_info extends AppCompatActivity
{
    private  String s="";
    private  String img="";
    private  String name="";

    private DatabaseReference dref1=null;

    private ImageView profile;
    private ImageView instagram;
    private ImageView  twitter;
    private ImageView  loco ;

    private RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    private ImageView youtube;
    private ImageView info;
    private ImageView i1;
    private ImageView i2;

    private TextView sub_text;
    private  TextView name_cc;

    private  ImageView discord;
    private Button subscribe;

    private ImageView yt1;
    private ImageView yt2;
    private ImageView yt3;
    private ImageView insta1;
    private ImageView insta2;
    private ImageView insta3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content_creator_info);

        MaterialToolbar materialToolbar;
        materialToolbar=findViewById(R.id.top_bar);

        materialToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });

        recyclerView = findViewById(R.id.recycleinfo);
        //  recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(content_creator_info.this);
        recyclerView.setLayoutManager(layoutManager);
        name_cc=findViewById(R.id.infoname);
        // sub_text =findViewById(R.id.subtext);
        profile=findViewById(R.id.infoimage1);
        i1=findViewById(R.id.infoimage1);
        i2=findViewById(R.id.scout_two);
        instagram=findViewById(R.id.ibutton85);
        twitter=findViewById(R.id.ibutton2);
        loco=findViewById(R.id.ibutton3);
        discord=findViewById(R.id.ibutton8);
        youtube=findViewById(R.id.ibutton1);
        info=findViewById(R.id.ibutton);
        subscribe=findViewById(R.id.switchcc);

        img=getIntent().getStringExtra("Image");
        name=getIntent().getStringExtra("Name");

        insta1=findViewById(R.id.insta1);
        insta1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.instagram.com/reel/Cn1XWPYg-H0/?igshid=YmMyMTA2M2Y="));
                startActivity(intent);

            }
        });

        insta2=findViewById(R.id.insta2);
        insta2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.instagram.com/p/CnfJLdbLTpR/?igshid=YmMyMTA2M2Y="));
                startActivity(intent);

            }
        });

        insta3=findViewById(R.id.insta3);
        insta3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://www.instagram.com/p/CnEllX_ob9x/?igshid=YmMyMTA2M2Y="));
                startActivity(intent);

            }
        });




        yt1=findViewById(R.id.yt1);
        yt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://youtu.be/nQFXKr7XvaI"));
                startActivity(intent);

            }
        });

        yt2=findViewById(R.id.yt2);
        yt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://youtu.be/baJ7Mb0IwKQ"));
                startActivity(intent);

            }
        });

        yt3=findViewById(R.id.yt3);
        yt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setData(Uri.parse("https://youtu.be/DQ3IHcLK4Pg"));
                startActivity(intent);

            }
        });








        dref1=FirebaseDatabase.getInstance().getReference();
        s=getIntent().getStringExtra("Id");


        if(FirebaseAuth.getInstance().getCurrentUser()!=null)
        {
            FirebaseDatabase.getInstance().getReference().child("People").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("SubscribedCreators").child(s).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.exists())
                    {

                        subscribe.setText("SUBSCRIBED");
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });


        }





        subscribe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (subscribe.getText().toString().equals("SUBSCRIBE")) {

                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                    if (user == null) {
                        Intent it = new Intent(content_creator_info.this, new_login.class);
                        startActivity(it);

                    } else {
                        subscribe.setText("SUBSCRIBED");
                        FirebaseMessaging.getInstance().subscribeToTopic(s)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        String msg = "Subscribed";
                                        if (!task.isSuccessful()) {
                                            msg = "Subscribe failed";
                                        } else {
                                            Log.d("TAG", msg);
                                            Map<String,Object>  map=new HashMap<>();
                                            map.put("Id",s);
                                            map.put("Image",img);
                                            map.put("Name",name);
                                            DatabaseReference dref = FirebaseDatabase.getInstance().getReference();
                                            dref.child("People").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("SubscribedCreators").child(s).updateChildren(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    Toast.makeText(content_creator_info.this, "Subscription Added", Toast.LENGTH_LONG).show();
                                                }
                                            });
                                        }
                                    }
                                });
                    }
                }
                else {

                    if (FirebaseAuth.getInstance().getCurrentUser() == null) {
                        Intent it = new Intent(content_creator_info.this, new_login.class);
                        startActivity(it);

                    } else {


                        subscribe.setText("SUBSCRIBE");
                        FirebaseMessaging.getInstance().unsubscribeFromTopic(s).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {


                                DatabaseReference dref = FirebaseDatabase.getInstance().getReference().child("People").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("SubscribedCreators").child(s);
                                dref.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        Toast.makeText(content_creator_info.this, "Unsubscribed", Toast.LENGTH_SHORT).show();
                                    }
                                });

                            }
                        });
                    }




                }
            }
        });






        dref1.child("Users").child(s).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ContentCreatorsData data =snapshot.getValue(ContentCreatorsData.class);

                name_cc.setText(data.getName());

                instagram.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        assert data != null;
                        Intent viewIntent =
                                new Intent("android.intent.action.VIEW",
                                        Uri.parse(data.getInstagramLink()));
                        startActivity(viewIntent);
                    }
                });
                twitter.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        assert data != null;
                        Intent viewIntent =
                                new Intent("android.intent.action.VIEW",
                                        Uri.parse(data.getTwitterLink()));
                        startActivity(viewIntent);
                    }
                });
                youtube.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        assert data != null;
                        Intent viewIntent =
                                new Intent("android.intent.action.VIEW",
                                        Uri.parse(data.getYoutubeLink()));
                        startActivity(viewIntent);
                    }
                });
                loco.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        assert data != null;
                        Intent viewIntent =
                                new Intent("android.intent.action.VIEW",
                                        Uri.parse(data.getLocoLink()));
                        startActivity(viewIntent);
                    }
                });

                Picasso.get().load(data.getImageUrl1()).into(i1);
                Picasso.get().load(data.getImageUrl2()).into(i2);

                discord.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent viewIntent =
                                new Intent("android.intent.action.VIEW",
                                        Uri.parse(data.getDiscordLink()));
                        startActivity(viewIntent);
                    }
                });


                assert data != null;
                if(data.getIsLive().equals("yes"))
                {



                }



            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        DatabaseReference users;
        users = FirebaseDatabase.getInstance().getReference().child("Posts").child(s);
        FirebaseRecyclerOptions<Postdata> options = new FirebaseRecyclerOptions.Builder<Postdata>()
                .setQuery(users, Postdata.class)
                .build();
        FirebaseRecyclerAdapter<Postdata,PostCreatorViewHolder> adapter = new FirebaseRecyclerAdapter<Postdata,PostCreatorViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull PostCreatorViewHolder holder, int position, @NonNull final Postdata model) {

                holder.cc_name.setText(model.getContent());

                Picasso.get().load(model.getImageUrl1()).into(holder.cc_image);

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        Intent viewIntent =
                                new Intent("android.intent.action.VIEW",
                                        Uri.parse(model.getPostLink()));
                        startActivity(viewIntent);

                        //  Intent it=new Intent(content_creator_info.this,content_creator_info.class);
                        //  it.putExtra("Id",model.getId());

                        //  startActivity(it);


                    }
                });

            }

            @NonNull
            @Override
            public PostCreatorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.creatorspost, parent, false);
                PostCreatorViewHolder holder = new PostCreatorViewHolder(view);

                return holder;
            }
        };
        recyclerView.setAdapter(adapter);
        adapter.startListening();
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }






}



