package com.example.s8ulorg.model;

public class ContentCreators {
    private String name;


    private String instagram;

    public ContentCreators() {
    }

    private String twitter;


    private String youtube;



    private String discord;


    private String loco;


    private String info;


    public ContentCreators(String name, String instagram, String twitter, String youtube, String discord, String loco, String info) {
        this.name = name;
        this.instagram = instagram;
        this.twitter = twitter;
        this.youtube = youtube;
        this.discord = discord;
        this.loco = loco;
        this.info = info;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInstagram() {
        return instagram;
    }

    public void setInstagram(String instagram) {
        this.instagram = instagram;
    }

    public String getTwitter() {
        return twitter;
    }

    public void setTwitter(String twitter) {
        this.twitter = twitter;
    }

    public String getYoutube() {
        return youtube;
    }

    public void setYoutube(String youtube) {
        this.youtube = youtube;
    }

    public String getDiscord() {
        return discord;
    }

    public void setDiscord(String discord) {
        this.discord = discord;
    }

    public String getLoco() {
        return loco;
    }

    public void setLoco(String loco) {
        this.loco = loco;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }


}
