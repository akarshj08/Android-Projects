package com.example.s8ulorg.retrofit;
import com.example.s8ulorg.model.ContentCreators;
import com.example.s8ulorg.model.NotificationDta;
import com.example.s8ulorg.model.NotificationDta;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.GET;

public interface EmployeeApi {


    @POST("/api/content/")
    Call<NotificationDta> sendnotification1(@Body NotificationDta data1);
}
