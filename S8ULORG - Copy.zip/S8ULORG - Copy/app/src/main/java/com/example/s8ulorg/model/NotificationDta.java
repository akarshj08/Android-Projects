package com.example.s8ulorg.model;

public class NotificationDta {

    private String token_user;

    public String getToken_user() {
        return token_user;
    }

    public NotificationDta() {
    }

    public NotificationDta(String token_user) {
        this.token_user = token_user;
    }

    public void setToken_user(String token_user) {
        this.token_user = token_user;
    }
}
