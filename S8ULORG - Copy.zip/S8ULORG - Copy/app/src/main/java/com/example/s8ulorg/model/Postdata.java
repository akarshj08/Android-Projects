package com.example.s8ulorg.model;

public class Postdata {


    private  String ImageUrl1;
    private  String Content;
    private  String PostLink;
    private String Id;
    private String PostId;

    public Postdata() {
    }

    public Postdata(String imageUrl1, String content, String postLink, String id, String postId) {
        ImageUrl1 = imageUrl1;
        Content = content;
        PostLink = postLink;
        Id = id;
        PostId = postId;
    }

    public String getImageUrl1() {
        return ImageUrl1;
    }

    public void setImageUrl1(String imageUrl1) {
        ImageUrl1 = imageUrl1;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }

    public String getPostLink() {
        return PostLink;
    }

    public void setPostLink(String postLink) {
        PostLink = postLink;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getPostId() {
        return PostId;
    }

    public void setPostId(String postId) {
        PostId = postId;
    }
}
