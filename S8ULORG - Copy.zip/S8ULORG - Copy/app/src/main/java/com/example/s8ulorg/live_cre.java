package com.example.s8ulorg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import com.example.s8ulorg.model.ContentCreatorsData;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class live_cre extends AppCompatActivity {


    private RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
  //  private DatabaseReference users;
    FirebaseRecyclerAdapter<ContentCreatorsData,LiveCreatorListViewHolder> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_cre);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        MaterialToolbar materialToolbar;
        materialToolbar=findViewById(R.id.top_bar);

        materialToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });


        recyclerView = findViewById(R.id.recyclelive);
       // recyclerView.setHasFixedSize(true);
        layoutManager =new GridLayoutManager(live_cre.this,2,LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);







        Query query = FirebaseDatabase.getInstance().getReference().child("Users").orderByChild("isLive").equalTo("yes");

      //  users = FirebaseDatabase.getInstance().getReference().child("Users");
        FirebaseRecyclerOptions<ContentCreatorsData> options = new FirebaseRecyclerOptions.Builder<ContentCreatorsData>()
                .setQuery(query, ContentCreatorsData.class)
                .build();
       adapter = new FirebaseRecyclerAdapter<ContentCreatorsData, LiveCreatorListViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull LiveCreatorListViewHolder holder, int position, @NonNull final ContentCreatorsData model) {

                {
                    holder.cc_name.setText(new StringBuilder().append(model.getName()).append(" ").append("").toString());

                    Picasso.get().load(model.getImageUrl1()).into(holder.cc_image);

                    holder.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {


                            Intent it = new Intent(live_cre.this, content_creator_info.class);
                            it.putExtra("Id", model.getId());
                            startActivity(it);
                          //  finish();


                        }
                    });
                }
               // holder.setIsRecyclable(false);

          }

            @NonNull
            @Override
            public LiveCreatorListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.live_content_creator, parent, false);
                LiveCreatorListViewHolder holder = new LiveCreatorListViewHolder(view);

                return holder;
            }


           @Override
           public long getItemId(int position) {
               return position;
           }

           @Override
           public int getItemViewType(int position) {
               return position;
           }
        };
        recyclerView.setAdapter(adapter);
       // adapter.startListening();
    }
    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }
    @Override
    public  void  onStop()
    {

        super.onStop();
        adapter.stopListening();
    }
}