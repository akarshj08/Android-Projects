package com.example.s8ulorg.model;

public class ContentCreatorsList {

    private String Name;
    private  String ImageUrl1;

    public ContentCreatorsList() {
    }

    public ContentCreatorsList(String name, String imageUrl1) {
        Name = name;
        ImageUrl1 = imageUrl1;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getImageUrl1() {
        return ImageUrl1;
    }

    public void setImageUrl1(String imageUrl1) {
        ImageUrl1 = imageUrl1;
    }
}
