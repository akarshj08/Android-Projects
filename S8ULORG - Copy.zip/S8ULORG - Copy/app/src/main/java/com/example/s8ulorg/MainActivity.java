package com.example.s8ulorg;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static int SPLASH_SCR=3000;

    Animation topAnim, bottomAnim;
    ImageView image,image2,image3;
    TextView text1,text2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        topAnim= AnimationUtils.loadAnimation(this,R.anim.top_animat);
        bottomAnim= AnimationUtils.loadAnimation(this,R.anim.bottom_anim);

        image2=findViewById(R.id.imageView4);
        image=findViewById(R.id.imageView2);
        image3=findViewById(R.id.imageView3);
        text1=findViewById(R.id.textView);
        text2=findViewById(R.id.textView2);

        image2.setAnimation(topAnim);
        image.setAnimation(topAnim);
        image3.setAnimation(topAnim);
        text1.setAnimation(bottomAnim);
        text2.setAnimation(bottomAnim);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent= new Intent(MainActivity.this,dashboard.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCR);

    }
}