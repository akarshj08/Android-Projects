package com.example.s8ulorg;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    private Button button;
    private Button button2;
    private Button button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);

        Toolbar toolbar=findViewById(R.id.tool3);
        setSupportActionBar(toolbar);
        setTitle("Login");

        ActionBar actionBar= getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled(true);

        button=findViewById(R.id.login);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(Login.this,"Logging In",Toast.LENGTH_SHORT).show();
                Intent intent= new Intent(Login.this,dashboard.class);
                startActivity(intent);

            }
        });


        button2=findViewById(R.id.new_user);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(Login.this,"Opening Registration page",Toast.LENGTH_SHORT).show();
                Intent intent= new Intent(Login.this,user_register.class);
                startActivity(intent);

            }
        });

        button3=findViewById(R.id.forget);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(Login.this,"Password Changing ",Toast.LENGTH_SHORT).show();
                Intent intent= new Intent(Login.this,forget_pass.class);
                startActivity(intent);

            }
        });




    }
}