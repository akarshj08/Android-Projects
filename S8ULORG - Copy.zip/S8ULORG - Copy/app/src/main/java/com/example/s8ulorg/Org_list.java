package com.example.s8ulorg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;

public class Org_list extends AppCompatActivity {

    private ImageView imageView1;
    Animation topAnim;
    RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_org_list);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        MaterialToolbar toolbar=findViewById(R.id.top_bar);
        DrawerLayout drawerLayout=findViewById(R.id.navigation_view);
        NavigationView navigationView=findViewById(R.id.akarsh);

        topAnim= AnimationUtils.loadAnimation(this,R.anim.top_animat);

        relativeLayout=findViewById(R.id.ret);
        relativeLayout.setAnimation(topAnim);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                drawerLayout.openDrawer(GravityCompat.START);

            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id=item.getItemId();
                switch (id)
                {

                    case R.id.home7:
                        Toast.makeText(Org_list.this,"Login page",Toast.LENGTH_SHORT).show();
                        Intent intent1=new Intent(Org_list.this,Login.class);
                        startActivity(intent1);break;

                    case R.id.home5:
                        Toast.makeText(Org_list.this,"Notification",Toast.LENGTH_SHORT).show();
                        Intent intent2=new Intent(Org_list.this,notification.class);
                        startActivity(intent2);break;

                    case R.id.home6:
                        Toast.makeText(Org_list.this,"Issue Reported",Toast.LENGTH_SHORT).show();
                        Intent intent4=new Intent(Org_list.this,issue.class);
                        startActivity(intent4);break;

                    case R.id.home2:
                        Toast.makeText(Org_list.this,"About App",Toast.LENGTH_SHORT).show();
                        Intent intent5=new Intent(Org_list.this,about_app.class);
                        startActivity(intent5);break;

                    case R.id.home4:
                        Toast.makeText(Org_list.this,"Setting",Toast.LENGTH_SHORT).show();
                        Intent intent6=new Intent(Org_list.this,setting.class);
                        startActivity(intent6);break;

                    case R.id.home9:
                        Toast.makeText(Org_list.this,"Logout",Toast.LENGTH_SHORT).show();
                        Intent intent7=new Intent(Org_list.this,Org_list.class);
                        startActivity(intent7);break;

                    case R.id.home8:
                        Toast.makeText(Org_list.this,"Contact Page",Toast.LENGTH_SHORT).show();
                        Intent intent8=new Intent(Org_list.this,contact.class);
                        startActivity(intent8);break;

                    case R.id.home10:
                        Toast.makeText(Org_list.this,"Match Results",Toast.LENGTH_SHORT).show();
                        Intent intent10=new Intent(Org_list.this,Match_result.class);
                        startActivity(intent10);break;


                    default:
                        return true;

                }

                return true;

            }
        });


        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        imageView1=findViewById(R.id.org_s8ul);
        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent= new Intent(Org_list.this,MainActivity.class);
                startActivity(intent);

            }
        });


    }
}