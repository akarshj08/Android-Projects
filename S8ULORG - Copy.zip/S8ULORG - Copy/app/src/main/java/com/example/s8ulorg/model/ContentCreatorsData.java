package com.example.s8ulorg.model;

public class ContentCreatorsData {

    private   String DiscordLink;

    private  String isLive;

    private  String Information;

    private  String ImageUrl2;
    private String InstagramLink;
    private  String LocoLink;
    private  String Name;
    private  String TwitterLink;
    private  String Id;

    private  String YoutubeLink;

    public String getIsLive() {
        return isLive;
    }

    public void setIsLive(String isLive) {
        this.isLive = isLive;
    }

    private  String ImageUrl1;



    public ContentCreatorsData() {
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }


    public String getDiscordLink() {
        return DiscordLink;
    }

    public void setDiscordLink(String discordLink) {
        DiscordLink = discordLink;
    }

    public String getInformation() {
        return Information;
    }

    public void setInformation(String information) {
        Information = information;
    }

    public String getInstagramLink() {
        return InstagramLink;
    }

    public void setInstagramLink(String instagramLink) {
        InstagramLink = instagramLink;
    }

    public ContentCreatorsData(String discordLink, String isLive, String information, String imageUrl2, String instagramLink, String locoLink, String name, String twitterLink, String id, String youtubeLink, String imageUrl1) {
        DiscordLink = discordLink;
        this.isLive = isLive;
        Information = information;
        ImageUrl2 = imageUrl2;
        InstagramLink = instagramLink;
        LocoLink = locoLink;
        Name = name;
        TwitterLink = twitterLink;
        Id = id;
        YoutubeLink = youtubeLink;
        ImageUrl1 = imageUrl1;
    }

    public String getImageUrl2() {
        return ImageUrl2;
    }

    public void setImageUrl2(String imageUrl2) {
        ImageUrl2 = imageUrl2;
    }

    public String getLocoLink() {
        return LocoLink;
    }

    public void setLocoLink(String locoLink) {
        LocoLink = locoLink;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getTwitterLink() {
        return TwitterLink;
    }

    public void setTwitterLink(String twitterLink) {
        TwitterLink = twitterLink;
    }



    public String getYoutubeLink() {
        return YoutubeLink;
    }

    public void setYoutubeLink(String youtubeLink) {
        YoutubeLink = youtubeLink;
    }

    public String getImageUrl1() {
        return ImageUrl1;
    }

    public void setImageUrl1(String imageUrl1) {
        ImageUrl1 = imageUrl1;
    }



}
