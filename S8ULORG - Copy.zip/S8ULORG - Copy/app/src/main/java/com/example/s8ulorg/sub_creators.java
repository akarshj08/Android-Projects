package com.example.s8ulorg;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import com.example.s8ulorg.model.ContentCreatorsData;
import com.example.s8ulorg.model.SubscribedData;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.List;

public class sub_creators extends AppCompatActivity {


      private  DatabaseReference dref;
    private RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_creators);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        MaterialToolbar materialToolbar;
        materialToolbar=findViewById(R.id.top_bar);

        materialToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });

        recyclerView = findViewById(R.id.recyclesub);
      //  recyclerView.setHasFixedSize(true);
        layoutManager = new GridLayoutManager(sub_creators.this,2,LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Intent it = new Intent(sub_creators.this, new_login.class);
            startActivity(it);
        }
        else {

        /*    List<String> list=new ArrayList<>();
            dref = FirebaseDatabase.getInstance().getReference().child("People").child(user.getUid()).child("SubscribedCreators");
            dref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    for (DataSnapshot postSnapshot: snapshot.getChildren()) {
                        list.add(postSnapshot.getValue(String.class));

                        Log.d("jhvjh",postSnapshot.getValue(String.class));
                    }

                    displaylist(list);

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });*/

            displaylist();
        }


    }

    private void displaylist() {
         DatabaseReference users;
        users = FirebaseDatabase.getInstance().getReference().child("People").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("SubscribedCreators");
        FirebaseRecyclerOptions<SubscribedData> options = new FirebaseRecyclerOptions.Builder<SubscribedData>()
                .setQuery(users, SubscribedData.class)
                .build();
        FirebaseRecyclerAdapter<SubscribedData,SubscribedCreatorViewHolder> adapter = new FirebaseRecyclerAdapter<SubscribedData, SubscribedCreatorViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull SubscribedCreatorViewHolder holder, int position, @NonNull final SubscribedData model) {



                    holder.cc_name.setText(model.getName());

                    Picasso.get().load(model.getImage()).into(holder.cc_image);

                    holder.itemView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {


                            Intent it = new Intent(sub_creators.this, content_creator_info.class);
                            it.putExtra("Id", model.getId());


                            it.putExtra("Image",model.getImage());
                            it.putExtra("Name",model.getName());

                            startActivity(it);


                        }
                    });


            }

            @NonNull
            @Override
            public SubscribedCreatorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.subscribedcreatorlook, parent, false);
                SubscribedCreatorViewHolder holder = new SubscribedCreatorViewHolder(view);

                return holder;
            }
        };
        recyclerView.setAdapter(adapter);
        adapter.startListening();


    }
    @Override
    public  void  onStart() {


        super.onStart();
        if(FirebaseAuth.getInstance().getCurrentUser()==null)
        {
            Intent it=new Intent(sub_creators.this,new_login.class);
            startActivity(it);
        }

    }
}