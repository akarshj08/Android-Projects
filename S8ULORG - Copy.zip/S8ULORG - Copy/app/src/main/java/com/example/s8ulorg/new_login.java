package com.example.s8ulorg;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

public class new_login extends AppCompatActivity {

  private  Button button1;
    private EditText editText1;
    NetworkChangeListner networkChangeListener = new NetworkChangeListner();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_login);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        editText1 = findViewById(R.id.enter_mobile_no);
        button1=findViewById(R.id.getotp);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (editText1.getText().toString().trim().isEmpty())
                    editText1.setError("Enter Valid Mobile Number");

                else if (editText1.getText().toString().trim().length() != 10)
                    editText1.setError("Enter Valid Mobile Number");

                else {

                    Intent intent = new Intent(new_login.this, otp_submit.class);
                    intent.putExtra("mobile",editText1.getText().toString());
                    startActivity(intent);
                }


            }
        });

    }
    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(networkChangeListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(networkChangeListener);
        super.onStop();
    }
}