package com.example.s8ulorg;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager2.widget.ViewPager2;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
public class dashboard extends AppCompatActivity
{

    private CardView cardView1;
    private CardView cardView5;
    private CardView cardView6;
    private CardView cardView3;
    private CardView cardView4;
    private CardView cardView2;

    TabLayout tabLayout;
    ViewPager2 viewPager2;
    pageadapter pagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_dashboard);

        tabLayout=findViewById(R.id.tablayout);
        viewPager2=findViewById(R.id.view_page);
       pagerAdapter=new pageadapter(this);
       viewPager2.setAdapter(pagerAdapter);

       tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener()
       {

           @Override
           public void onTabSelected(TabLayout.Tab tab)
           {

               viewPager2.setCurrentItem(tab.getPosition());

           }

           @Override
           public void onTabUnselected(TabLayout.Tab tab)
           {


           }

           @Override
           public void onTabReselected(TabLayout.Tab tab)
           {


           }
       });

       viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
           @Override
           public void onPageSelected(int position) {
               super.onPageSelected(position);
               tabLayout.getTabAt(position).select();
           }
       });

        MaterialToolbar toolbar=findViewById(R.id.top_bar);
        DrawerLayout drawerLayout=findViewById(R.id.navigation_view);
        NavigationView navigationView=findViewById(R.id.akarsh);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                drawerLayout.openDrawer(GravityCompat.START);

            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
               int id=item.getItemId();
               switch (id)
               {

                   case R.id.home7:
                       Toast.makeText(dashboard.this,"Login page",Toast.LENGTH_SHORT).show();
                       Intent intent1=new Intent(dashboard.this,new_login.class);
                       startActivity(intent1);break;

                   case R.id.home5:
                       Toast.makeText(dashboard.this,"Notification",Toast.LENGTH_SHORT).show();
                       Intent intent2=new Intent(dashboard.this,notification.class);
                       startActivity(intent2);break;

                   case R.id.home3:
                       Toast.makeText(dashboard.this,"Organisation Info",Toast.LENGTH_SHORT).show();
                       Intent intent3=new Intent(dashboard.this,org_info.class);
                       startActivity(intent3);break;

                   case R.id.home6:
                       Toast.makeText(dashboard.this,"Report Issue",Toast.LENGTH_SHORT).show();
                       Intent intent4=new Intent(dashboard.this,issue.class);
                       startActivity(intent4);break;

                   case R.id.home2:
                       Toast.makeText(dashboard.this,"About App",Toast.LENGTH_SHORT).show();
                       Intent intent5=new Intent(dashboard.this,about_app.class);
                       startActivity(intent5);break;

                   case R.id.home4:
                       Toast.makeText(dashboard.this,"Setting",Toast.LENGTH_SHORT).show();
                       Intent intent6=new Intent(dashboard.this,setting.class);
                       startActivity(intent6);break;

                   case R.id.home9:
                       Toast.makeText(dashboard.this,"Logout",Toast.LENGTH_SHORT).show();
                       Intent intent7=new Intent(dashboard.this,dashboard.class);
                       startActivity(intent7);break;

                   case R.id.home8:
                       Toast.makeText(dashboard.this,"Contact Page",Toast.LENGTH_SHORT).show();
                       Intent intent8=new Intent(dashboard.this,contact.class);
                       startActivity(intent8);break;

                   case R.id.home10:
                       Toast.makeText(dashboard.this,"Match Results",Toast.LENGTH_SHORT).show();
                       Intent intent10=new Intent(dashboard.this,Match_result.class);
                       startActivity(intent10);break;

                   default:
                       return true;

               }

               return true;

            }
        });



        cardView1=findViewById(R.id.content_creator);
        cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent= new Intent(dashboard.this,ListContentCreators.class);
                startActivity(intent);

            }
        });


        cardView3=findViewById(R.id.merchandise);
        cardView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent= new Intent(dashboard.this,merch.class);
                startActivity(intent);

            }
        });


        cardView4=findViewById(R.id.patnership);
        cardView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent= new Intent(dashboard.this,patners.class);
                startActivity(intent);

            }
        });

        cardView2=findViewById(R.id.subscibed_creator);
        cardView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent= new Intent(dashboard.this,sub_creators.class);
                startActivity(intent);

            }
        });

        cardView5=findViewById(R.id.live_creators);
        cardView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent= new Intent(dashboard.this,live_cre.class);
                startActivity(intent);

            }
        });

        cardView6=findViewById(R.id.giveaways);
        cardView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent= new Intent(dashboard.this,giveaways.class);
                startActivity(intent);

            }
        });



    }
}
    