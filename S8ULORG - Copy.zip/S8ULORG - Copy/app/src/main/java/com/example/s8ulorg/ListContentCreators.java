package com.example.s8ulorg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import com.example.s8ulorg.model.ContentCreatorsData;
import com.example.s8ulorg.model.ContentCreatorsData;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class ListContentCreators extends AppCompatActivity {


    private RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;
    private DatabaseReference  users;
    private   FirebaseRecyclerAdapter<ContentCreatorsData,ContentCreatorsListViewHolder> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_content_creators);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        MaterialToolbar materialToolbar;
        materialToolbar=findViewById(R.id.top_bar);

        materialToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });

        recyclerView = findViewById(R.id.recycle00);
        layoutManager =new GridLayoutManager(ListContentCreators.this,2,LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);


        users = FirebaseDatabase.getInstance().getReference().child("Users");
        FirebaseRecyclerOptions<ContentCreatorsData> options = new FirebaseRecyclerOptions.Builder<ContentCreatorsData>()
                .setQuery(users, ContentCreatorsData.class)
                .build();
        adapter = new FirebaseRecyclerAdapter<ContentCreatorsData, ContentCreatorsListViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull ContentCreatorsListViewHolder holder, int position, @NonNull final ContentCreatorsData model) {

                holder.cc_name.setText(model.getName());

                Picasso.get().load(model.getImageUrl1()).into(holder.cc_image);

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                    Intent it=new Intent(ListContentCreators.this,content_creator_info.class);
                    it.putExtra("Id",model.getId());
                     it.putExtra("Image",model.getImageUrl1());
                     it.putExtra("Name",model.getName());
                    startActivity(it);


                    }
                });

               // holder.setIsRecyclable(false);


            }

            @NonNull
            @Override
            public ContentCreatorsListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.content_creators_list, parent, false);
               ContentCreatorsListViewHolder holder = new ContentCreatorsListViewHolder(view);

                return holder;
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public int getItemViewType(int position) {
                return position;
            }
        };

        recyclerView.setAdapter(adapter);

       // adapter.startListening();
    }

    @Override
    public  void onStart() {
        super.onStart();
        adapter.startListening();
    }
    @Override
    public  void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }


}