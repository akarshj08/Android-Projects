package com.example.s8ulorg;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class LiveCreatorListViewHolder  extends RecyclerView.ViewHolder implements View.OnClickListener{

    public ItemClickListner listner;
    public TextView cc_name;
    public ImageView cc_image;
    public LiveCreatorListViewHolder(@NonNull View itemView) {
        super(itemView);
        cc_image =itemView.findViewById(R.id.liveimage);
        cc_name=itemView.findViewById(R.id.livetext);

    }
    public  void setItemClickListener(ItemClickListner listner)
    {
        this.listner=listner;

    }
    @Override
    public void onClick(View view) {

        listner.onClick(view,getAdapterPosition(),false);

    }
}

