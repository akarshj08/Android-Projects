package com.example.s8ulorg;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.s8ulorg.model.ContentCreators;
import com.example.s8ulorg.model.NotificationDta;
import com.example.s8ulorg.retrofit.EmployeeApi;
import com.example.s8ulorg.retrofit.RetrofitService;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class LiveActivity extends AppCompatActivity {


    Button bt;
    FIrebaseService service;
    private String phonenumber;
    private String ids;
  private   String token1 = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live);
        bt = findViewById(R.id.button);
       // phonenumber = getIntent().getStringExtra("Number");
       // ids = getIntent().getStringExtra("ID");

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseMessaging.getInstance().subscribeToTopic("akarsh")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Subscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Subscribe failed";
                                }
                                Log.d("TAG", msg);
                                Toast.makeText(LiveActivity.this, msg, Toast.LENGTH_SHORT).show();
                            }
                        });

            }
        });

     /* valid   FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            Log.w("TAG", "Fetching FCM registration token failed", task.getException());
                            return;
                        }

                        // Get new FCM registration token
                        token1 = task.getResult();


                        NotificationDta data1 = new NotificationDta();
                        data1.setToken_user(token1);
                        Log.d("jhuiu", data1.getToken_user());


                        RetrofitService retrofitService = new RetrofitService();
                        EmployeeApi employeeApi = retrofitService.getRetrofit().create(EmployeeApi.class);

                        employeeApi.sendnotification1(data1)
                                .enqueue(new Callback<NotificationDta>() {
                                    @Override
                                    public void onResponse(Call<NotificationDta> call, Response<NotificationDta> response) {

                                        Log.d("gyg", response.toString());
                                        // Toast.makeText(LiveActivity.this,"Save ff",Toast.LENGTH_LONG).show();
                                    }

                                    @Override
                                    public void onFailure(Call<NotificationDta> call, Throwable t) {

                                        // Toast.makeText(LiveActivity.this,"Save failed",Toast.LENGTH_LONG).show();
                                        Logger.getLogger(LiveActivity.class.getName()).log(Level.SEVERE, "TDDRDA", t);
                                    }
                                });


                        // Log and toast
                        // String msg = getString(R.string.msg_token_fmt, token);
                        //Log.d(TAG, msg);
                        //   Toast.makeText(getApplicationContext(),"okk", Toast.LENGTH_SHORT).show();
                    }
                });*/



     /*   FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            Log.w("TAG", "Fetching FCM registration token failed", task.getException());

                            return;
                        }

                        // Get new FCM registration token
                        token1 = task.getResult();
                        bt.setVisibility(View.VISIBLE);
                        // Log and toast

                        Log.d("TAG243", token1);

                    }

                });*/





    }
}

       /* bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirebaseMessaging.getInstance().subscribeToTopic("newOrder")
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                String msg = "Subscribed";
                                if (!task.isSuccessful()) {
                                    msg = "Subscribe failed";
                                }
                                Log.d("TAG", msg);
                                Toast.makeText(LiveActivity.this, msg, Toast.LENGTH_SHORT).show();
                                bt.setVisibility(View.VISIBLE);
                                RequestQueue mRequestQue = Volley.newRequestQueue(LiveActivity.this);

                                JSONObject json = new JSONObject();
                                try {
                                    json.put("to", "/topics/" + "newOrder");
                                    JSONObject notificationObj = new JSONObject();
                                    notificationObj.put("title", "new Order");
                                    notificationObj.put("body", "New order from : " +"Aditi");
                                    //replace notification with data when went send data
                                    json.put("notification", notificationObj);

                                    String URL = "https://fcm.googleapis.com/fcm/send";
                                    JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, URL,
                                            json,
                                            response -> Log.d("MUR", "onResponse: "),
                                            error -> Log.d("MUR", "onError: " + error.networkResponse)
                                    ) {
                                        @Override
                                        public Map<String, String> getHeaders() {
                                            Map<String, String> header = new HashMap<>();
                                            header.put("content-type", "application/json");
                                            header.put("authorization", "key=AAAAtRr4Q-A:APA91bEOF9J4xv2YQdggGlNQ3_w82cpPY5rGNLet3LG7tOOkuF43POW_6APdOUTSSm3e0puHpslAqOiFyDeY5Dzz_ZyUIiq7c3UBVKKBTYvJXCOpyFdxmw0Zgr4VXPqEeYnlw3p3QmqM");
                                            return header;
                                        }
                                    };


                                    mRequestQue.add(request);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        });

            }
        });



    } */
